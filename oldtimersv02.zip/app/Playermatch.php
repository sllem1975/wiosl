<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Playermatch extends Model
{
    //
}
