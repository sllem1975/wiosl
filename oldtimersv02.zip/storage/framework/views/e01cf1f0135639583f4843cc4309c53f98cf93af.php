
<?php $__env->startSection('content'); ?>
<div class="container ">
  <div class="card border-primary m-2">
    <div class=" card-header  border-primary headerForm">
      <i class="fas fa-users fa-2x text-primary mt-3"></i>
      <h2 class="d-inline text-primary text-center  mt-3">Matches</h2>
    </div>
    <div class="card-body">

      <div class="input-group col-md-5 mb-2  ">
        <input class="form-control py-2 border-success" type="search" placeholder="Search by any field" id="myInput">
        <span class="input-group-append ">
          <button class="btn btn-outline-secondary  border-success" type="button">
            <i class="fa fa-search text-success"></i>
          </button>
        </span>
      </div>

      <div class="table-responsive ">
        <table class="table table-striped table-bordered table-hover table-sm ">
          <thead class="bg-dark text-white">
            <tr>
              <th>Id</th>
              <th>Week</th>
              <th>Date</th>
              <th>Home Team</th>
              <th>Home Score</th>
              <th>Away Score</th>
              <th>Away Team</th>
              <th>Time</th>
              <th>Field</th>
              <th>Type</th>
              <th>Status</th>
              <th>Action</th>

            </tr>
          </thead>
          <tbody id="myTable">
            <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><a href="/matches/<?php echo e($match->id); ?>"> <?php echo e($match->id); ?></th>
              <td><?php echo e($match->game_week); ?></td>
              
              <td> <a href="/matches/<?php echo e($match->id); ?>"> <?php echo e(date('l d-m-Y', strtotime($match->date))); ?></td>
              <td><?php echo e($match->team_home->name); ?></td>
              <td><?php echo e($match->home_score); ?></td>
              <td><?php echo e($match->away_score); ?></td>
              <td><?php echo e($match->team_away->name); ?></td>
              
              <td> <?php echo e(date('h:i A', strtotime($match->date))); ?> </td>
              <td><?php echo e($match->address->name); ?></td>

              <td>
                <?php if($match->address->type === 'GRASS'): ?>
                <span class="badge badge-success "><?php echo e($match->address->type); ?></span>
                <?php else: ?>
                <span class="badge badge-secondary "><?php echo e($match->address->type); ?></span>
                <?php endif; ?>
              </td>
              <td>
                <?php if( $match->status_id === 1 ): ?>
                <span class="badge badge-primary font-weight-bold"><?php echo e($match->status->name); ?></span>
                <?php endif; ?>
                <?php if( $match->status_id === 2 ): ?>
                <span class="text-danger font-weight-bold"><?php echo e($match->status->name); ?></span>
                <?php endif; ?>
              </td>

              <td>
                <a href="/matches/<?php echo e($match->id); ?>/edit" class="btn btn-sm btn-success ">Edit</a>                
                <a href="/matches/<?php echo e($match->id); ?>" class="btn btn-sm btn-info ">View</a>                
              </td>
              

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <?php echo e($matches->links()); ?>

      </div>
      <div class="m-2">
        <a class="pull-right btn btn-primary btn-sm" href="<?php echo e(route('matches.create')); ?>">Create new match</a>
      </div>

    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<!-- Scripts -->
<?php $__env->startPush('javascript'); ?>
<script src="<?php echo e(asset('js/others.js')); ?>"></script>    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Data\Websites\wiosl\project_wiosl\wiosl\resources\views/matches/index.blade.php ENDPATH**/ ?>