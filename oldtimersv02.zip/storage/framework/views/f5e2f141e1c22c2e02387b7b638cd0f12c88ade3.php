<?php if(session()->has('success')): ?>
    <div class="alert alert-dismissable alert-success fade show">
        <button type="button" class="close" data-dimiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <strong>
            <?php echo session()->get('success'); ?>

        </strong>
    </div>
<?php endif; ?>

<?php /**PATH C:\Data\Websites\wiosl\project_wiosl\wiosl\resources\views/partials/success.blade.php ENDPATH**/ ?>