<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title><?php echo e(config('app.name', 'West Island Oldtimers Soccer League')); ?></title>

  <!-- Scripts -->
  <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

  <!-- Scripts -->
  <script src="<?php echo e(asset('js/sidebar.js')); ?>" defer></script>

  <!-- Fonts -->
  <link rel="dns-prefetch" href="//fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

  <!-- Styles -->
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
  <!-- Styles -->
  <link href="<?php echo e(asset('css/welcome.css')); ?>" rel="stylesheet">


  <!-- Custom styles for this template -->
  <link href="/css/simple-sidebar.css" rel="stylesheet">

  <!-- Bootstrap core JavaScript
        ================================================== -->
  <!-- Placed at the end of the document so the pages load faster -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
    integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
  </script>
  <script>
    window.jQuery || document.write('<script src="../../../../assets/js/vendor/jquery-slim.min.js"><\/script>')
  </script>
  
  

  <!-- Icons -->
  <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
  <script>
    feather.replace()
  </script>


  
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>

  

  <?php echo $__env->yieldPushContent('css'); ?>
  <?php echo $__env->yieldPushContent('javascript'); ?>

</head>

<body>
  <div id="app">
    <div class="d-flex" id="wrapper" class="bghome">

      <!-- Sidebar -->
      <div class="bg-light border-right" id="sidebar-wrapper">
        <div class="sidebar-heading border-bottom">
          <a class="navbar-brand " href="<?php echo e(url('/')); ?>" title="West Island Oldtimers Soccer League">
            WIO Soccer League
          </a></div>
        <div class="list-group list-group-flush border ">
          <a href="<?php echo e(route('home.dashboard')); ?>"
            class="list-group-item list-group-item-action bg-light rounded">Dashboard</a>
          <a href="<?php echo e(route('matches.index')); ?>"
            class="list-group-item list-group-item-action bg-light rounded">Match</a>
          <a href="#" class="list-group-item list-group-item-action bg-light rounded">Teams</a>
          <a href="#" class="list-group-item list-group-item-action bg-light rounded">Players</a>
          <a href="<?php echo e(route('users.index')); ?>" class="list-group-item list-group-item-action bg-light rounded">Users</a>
          <a href="<?php echo e(route('users.index')); ?>"
            class="list-group-item list-group-item-action bg-light rounded">Status</a>
        </div>

      </div>
      <!-- /#sidebar-wrapper -->

      <!-- Page Content -->
      <div id="page-content-wrapper">

        <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
          <button class="btn btn-primary" id="menu-toggle">Toggle Menu</button>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto ">
              <!-- Authentication Links -->
              <?php if(auth()->guard()->guest()): ?>
              <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
              </li>
              <?php if(Route::has('register')): ?>
              <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
              </li>
              <?php endif; ?>
              <?php else: ?>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item dropdown">
                <a id="navbarDropdown" class="nav-link dropdown-toggle " href="#" role="button" data-toggle="dropdown"
                  aria-haspopup="true" aria-expanded="false" v-pre>
                  <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                </a>

                <div class="dropdown-menu dropdown-menu-right " aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                  </a>

                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                  </form>
                </div>
              </li>
              <?php endif; ?>
            </ul>
          </div>
        </nav>

        <div class="container-fluid ">
          
          <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php echo $__env->make('partials.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php echo $__env->yieldContent('content'); ?>

        </div>
      </div>
      <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->
  </div>


</body><?php /**PATH C:\Data\Websites\wiosl\project_wiosl\wiosl\resources\views/home.blade.php ENDPATH**/ ?>