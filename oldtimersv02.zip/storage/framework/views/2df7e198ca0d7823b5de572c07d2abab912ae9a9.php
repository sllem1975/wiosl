

<?php $__env->startSection('content'); ?>

<div class="container mt-4 mb-3">

    <div class="row justify-content-center ">

        <div class="col-md-12 col-lg-12 col-sm-12 pull-left">

            <div class="card">
                <div class="card-header bg-primary ">
                    <h5 class="text-white font-weight-bold ">Update Match </h5>
                </div>
                <div class="card-body">
                    <!-- Example to create form -->
                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12 ">

                            <!-- for this form I use method POST and the action rout is companies.update/1 -->
                            <form method="post" action="<?php echo e(route('matches.update', [$match->id])); ?>">
                                <?php echo e(csrf_field()); ?>

                                <!--  this if for create a key for hidden the information and avoid hackers-->

                                <!-- <input type="hidden" name="_method" value="put"> we don't need this method-->

                                <input type="hidden" name="_method" value="put">

                                <div class="form-group row">
                                    <label for="id" class="col-sm-2 col-form-label font-weight-bold">Game ID: </label>
                                    <div class="col-sm-10">
                                    <input type="text" class="form-control font-weight-bold" 
                                    id="id" 
                                    style="width:150px;"  
                                    value="<?php echo e($match->id); ?>"  
                                    name="id">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="season_id"
                                        class="col-sm-2 col-form-label font-weight-bold">Season:</label>
                                    <div class="col-sm-10">
                                        <select class="form-control text-danger font-weight-bold" 
                                        style="width:250px;"
                                        name="season_id"
                                            id="season_id">
                                            <?php $__currentLoopData = $season; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $season): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($season->id); ?>"
                                                <?php if($season->id === $match->season_id): ?>
                                                selected
                                                <?php endif; ?>
                                                >
                                                <?php echo e($season->season_name); ?>

                                                (<?php echo e($season->date_start); ?>)</option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="game_week" class="col-sm-2 col-form-label font-weight-bold">Game Week: </label>
                                    <div class="col-sm-10">
                                    <input type="number" class="form-control font-weight-bold" 
                                    id="game_week" 
                                    style="width:150px;"    
                                    name="game_week"
                                    value="<?php echo e($match->game_week); ?>"
                                    >
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="phase_id"
                                        class="col-sm-2 col-form-label font-weight-bold">Phase:</label>
                                    <div class="col-sm-10">
                                        <select class="form-control font-weight-bold" 
                                        style="width:250px;"
                                        name="phase_id"
                                            id="phase_id">
                                            <?php $__currentLoopData = $phase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($phase->id); ?>"
                                               <?php if($phase->id === $match->phase_id): ?>
                                                   selected
                                               <?php endif; ?> 
                                                >
                                                <?php echo e($phase->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="date"
                                        class="col-sm-2 col-form-label font-weight-bold">Date:</label>
                                    <div class="col-sm-10">
                                        <input placeholder="input date" 
                                                id="date" 
                                                type="datetime-local"
                                                name="date" 
                                                style="width:250px;"
                                                required
                                                onchange="invoicedue(event);"
                                                value="<?php echo e(date('Y-m-d\TH:i', strtotime($match->date))); ?>" 
                                                class="date form-control text-primary font-weight-bold" />
                                    </div>
                                </div>


                                <div class="form-group row">
                                    <label for="home_id"
                                        class="col-sm-2 col-form-label font-weight-bold">Home Team:</label>
                                    <div class="col-sm-10">
                                        <select class="form-control text-success font-weight-bold" name="home_id"
                                        style="width:250px;"
                                            id="home_id">
                                            <?php $__currentLoopData = $hometeam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hometeam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($hometeam->id); ?>"
                                                <?php if($hometeam->id === $match->home_id): ?>
                                                    selected
                                                <?php endif; ?>
                                                >
                                                <?php echo e($hometeam->name); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>


                                <div class="form-group row">
                                    <label for="home_score" class="col-sm-2 col-form-label font-weight-bold">Home Score: </label>
                                    <div class="col-sm-10">
                                    <input type="number" class="form-control font-weight-bold" 
                                    style="width:150px;"
                                    id="home_score"
                                    value="<?php echo e($match->home_score); ?>" 
                                        name="home_score">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="away_id"
                                        class="col-sm-2 col-form-label font-weight-bold">Away Team:</label>
                                    <div class="col-sm-10">
                                        <select class="form-control text-success font-weight-bold" 
                                        name="away_id"
                                        style="width:250px;"
                                            id="away_id">
                                            <?php $__currentLoopData = $awayteam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $awayteam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($awayteam->id); ?>" 
                                                <?php if($awayteam->id === $match->away_id): ?>
                                                    selected
                                                <?php endif; ?>
                                                >
                                                <?php echo e($awayteam->name); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="away_score" class="col-sm-2 col-form-label font-weight-bold">Away Score: </label>
                                    <div class="col-sm-10">
                                    <input type="number" class="form-control font-weight-bold" 
                                    style="width:150px;"
                                    id="away_score" 
                                    value="<?php echo e($match->away_score); ?>"
                                        name="away_score">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="stadium_id"
                                        class="col-sm-2 col-form-label font-weight-bold">Stadium:</label>
                                    <div class="col-sm-10">
                                        <select class="form-control text-info font-weight-bold" name="stadium_id"
                                        style="width: 350px"
                                            id="stadium_id">
                                            <?php $__currentLoopData = $address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($address->id); ?>"
                                                <?php if($address->id === $match->stadium_id): ?>
                                                    selected
                                                <?php endif; ?>
                                                >
                                                <?php echo e($address->name); ?> ( <?php echo e($address->type); ?> )
                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="status_id"
                                        class="col-sm-2 col-form-label font-weight-bold">Status:</label>
                                    <div class="col-sm-10">
                                        <select class="form-control text-secondary font-weight-bold" name="status_id"
                                        style="width:250px;"
                                            id="status_id">
                                            <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($status->id); ?>"
                                                <?php if($status->id === $match->status_id): ?>
                                                    selected
                                                <?php endif; ?>
                                                >
                                                <?php echo e($status->name); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="observation"
                                        class="col-sm-2 col-form-label font-weight-bold">observation:</label>
                                    <div class="col-sm-10">
                                        <textarea 
                                        class="form-control" 
                                        id="observation"
                                        rows="3"
                                        value="<?php echo e($match->observation); ?>"
                                        name="observation"
                                            ></textarea>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary" value="Submit" />
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>



        
</div>


<?php $__env->stopSection(); ?>
<!-- Scripts -->
<?php $__env->startPush('javascript'); ?>
<script src="<?php echo e(asset('js/matches_hidden.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Data\Websites\wiosl\project_wiosl\wiosl\resources\views/matches/_edit.blade.php ENDPATH**/ ?>