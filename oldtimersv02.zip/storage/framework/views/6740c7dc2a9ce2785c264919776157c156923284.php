
<?php $__env->startSection('content'); ?>
<div class="container ">
  <div class="card border-primary m-2">
    <div class=" card-header  border-primary headerForm">
      <i class="fas fa-users fa-2x text-primary mt-3"></i>
      <h2 class="d-inline text-primary text-center  mt-3">Users</h2>
    </div>
    <div class="card-body">

      <div class="input-group col-md-5 mb-2  ">
        <input class="form-control py-2 border-success" type="search" placeholder="Search by any field" id="myInput">
        <span class="input-group-append ">
          <button class="btn btn-outline-secondary  border-success" type="button">
            <i class="fa fa-search text-success"></i>
          </button>
        </span>
      </div>

      <div class="table-responsive">
        <table class="table table-hover">
          <thead class="table-dark">
            <tr>
              <th scope="col"># ID</th>
              <th scope="col" class="text-left">name</th>
              <th scope="col" class="text-left">email</th>
              <th scope="col">Role</th>
              <th scope="col">Status</th>
              <th scope="col">Actions</th>
            </tr>
          </thead>
          <tbody id="myTable">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              
              <th scope="row"><a href="<?php echo e($user->url); ?>"> <?php echo e($user->id); ?></th>
              <td class="text-left"><a href="/user/<?php echo e($user->id); ?>"><?php echo e($user->name); ?> <?php echo e($user->last_name); ?></td>
              <td class="text-left"><?php echo e($user->email); ?> </td>

              <td>
                <?php if( $user->role_id == 1 ): ?>
                <h5><span class="badge badge-success"><?php echo e($user->role->name); ?> </h5>
                <?php elseif( $user->role_id == 2 ): ?>
                <h5><span class="badge badge-info"><?php echo e($user->role->name); ?> </h5>
                <?php else: ?>
                <h5><span class="badge badge-secondary"><?php echo e($user->role->name); ?> </h5>
                <?php endif; ?>
              </td>

              <?php if( $user->status_id == 1 ): ?>
              <td>
                <h5><span class="badge badge-primary "><?php echo e($user->status->name); ?></span></h5>
              </td>

              <?php elseif( $user->status_id == 2 ): ?>
              <td>
                <h5><span class="badge badge-danger "><?php echo e($user->status->name); ?></span></h5>
              </td>
              <?php endif; ?>

              <td>
                <a href="/users/<?php echo e($user->id); ?>/edit" class="btn btn-sm btn-success ">Edit</a>

              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <div>
          <?php echo e($users->links()); ?>

        </div>

      </div>
      <div class="m-2">
        <a class="pull-right btn btn-primary btn-sm" href="<?php echo e(route('users.create')); ?>">Create new User</a>
      </div>

    </div>
  </div>
</div>
<script>
  $('.delete-user').click(function(e){
        e.preventDefault() // Don't post the form, unless confirmed
        if (confirm('Are you sure?')) {
            // Post the form
            $(e.target).closest('form').submit() // Post the surrounding form
        }
    });

    
</script>
<?php $__env->stopSection(); ?>

<!-- Scripts -->
<?php $__env->startPush('javascript'); ?>
<script src="<?php echo e(asset('js/others.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Data\wiosl\project_wiosl\wiosl\resources\views/users/index.blade.php ENDPATH**/ ?>